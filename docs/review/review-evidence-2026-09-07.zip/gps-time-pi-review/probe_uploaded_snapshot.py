"""Focused, non-hardware regression probes for the uploaded GPS Time Pi snapshot.

These probes demonstrate current behavior; they are NOT passing acceptance tests.
They mock gpsd/chrony and never restart a service, touch /opt, or change a clock.
"""
from pathlib import Path
import json
import os
import sys
import tempfile
from unittest.mock import patch

import argparse
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repo', type=Path, default=Path(__file__).resolve().parent / 'gps-time-pi',
                    help='Path to the extracted gps-time-pi source directory')
ROOT = parser.parse_args().repo.resolve()
if not (ROOT / 'gps_time_pi' / 'gps.py').is_file():
    parser.error(f'No GPS Time Pi source found at {ROOT}; provide --repo /path/to/gps-time-pi')
sys.path.insert(0, str(ROOT))
SCRATCH = Path(tempfile.mkdtemp(prefix='gps-time-pi-probe-'))
os.environ['GTP_CONFIG'] = str(SCRATCH / 'config.json')
from gps_time_pi import config, gps, chrony, server

results = []
def add(name, evidence):
    results.append({'name': name, 'evidence': evidence})

# A new fix, then total gpsd silence. The old fix must not become a new observation.
config._CACHE = {'location_display': 'exact', 'site': None}
config._LAST_WRITE = 0
fix = {'mode': 3, 'lat': 40.0, 'lon': -75.0,
       'altMSL': 100.0, 'altHAE': 70.0, 'time': '2026-09-07T12:00:00Z'}
sky = {'satellites': [{'PRN': 1, 'used': True, 'ss': 40}]}
gps._cache = {'t': 0, 'tpv': {}, 'sky': {}, 'version': {}, 'device': {}}
gps._last_site_write = 0
gps._FIXES.clear()
with patch.object(gps.time, 'time', return_value=1000.0), patch.object(gps, '_poll', return_value=(fix, sky, {}, {})):
    first = gps.snapshot()
    n_first = config.load()['site']['n_lat']
with patch.object(gps.time, 'time', return_value=1065.0), patch.object(gps, '_poll', return_value=({}, {}, {}, {})):
    stale = gps.snapshot()
    n_stale = config.load()['site']['n_lat']
add('Stale GPS fix accepted again after gpsd silence', {
    'n_before': n_first, 'n_after': n_stale,
    'reported_live_time': stale['live']['time'],
    'reported_data_age_s': stale['data_age_s'],
    'computed_horizontal_standard_error_m': config.site_stats(config.load())['se_horiz_m'],
})

# The existing survey is not the observing site while live GPS is available.
with patch.object(gps, 'snapshot', return_value={'live': {'lat': 41.0, 'lon': -74.0, 'alt_msl': 200.0}}):
    selected, provenance = gps.observing_site()
add('Astronomy selects live fix rather than survey', {
    'stored_survey_lat': config.load()['site']['lat'],
    'selected_lat': selected['lat'], 'provenance': provenance,
})

# 14 fields in the documented chrony 4.x tracking log layout, invented values.
log = SCRATCH / 'tracking.log'
log.write_text('2026-09-07 12:00:00 192.0.2.1 2 -1.0 0.1 2.0e-6 N 2 4.0e-6 -5.0e-6 2.0e-3 2.0e-4 3.0e-3\n')
with patch.object(chrony, 'TRACKING_LOG', str(log)):
    point = chrony.history()['points'][0]
add('History error band uses wrong field', {
    'returned_err_s': point['err_s'],
    'field10_combined_offset_stddev_s': 4e-6,
    'field12_root_delay_s': 2e-3,
    'field13_root_dispersion_s': 2e-4,
    'field14_previous_interval_max_error_s': 3e-3,
})

# Remaining correction can have either sign. When positive, it is used
# instead, demonstrating a change in the returned quantity's meaning.
log.write_text('2026-09-07 12:01:00 192.0.2.1 2 -1.0 0.1 2.0e-6 N 2 4.0e-6 5.0e-6 2.0e-3 2.0e-4 3.0e-3\n')
with patch.object(chrony, 'TRACKING_LOG', str(log)):
    point = chrony.history()['points'][0]
add('Positive remaining correction becomes reported uncertainty', {'returned_err_s': point['err_s'], 'actual_field_used': '11: remaining correction'})

# Handler route is exercised with a harmless mock instead of a privileged action.
h = object.__new__(server.Handler)
h.path = '/api/admin?action=reboot'
h._json = lambda obj: None
with patch.object(server.system, 'admin', return_value={'ok': True}) as admin:
    h.do_GET()
add('GET admin route invokes action without authentication', {'mock_action_calls': [str(c) for c in admin.call_args_list]})

# Verify app Python syntax without installing or running hardware services.
pyfiles = list(ROOT.rglob('*.py'))
for path in pyfiles:
    compile(path.read_text(), str(path), 'exec')
add('Python syntax', {'files_compiled': len(pyfiles), 'errors': 0})

print(json.dumps(results, indent=2))
