# GPS Time Pi review and scope evidence

This package contains a source review and proposed scope, not an updated application.
No deployment files have been patched. No Pi hardware accuracy or shutdown/power-loss
behavior has been measured by these probes.

## Contents

- GPS-Time-Pi-Review-and-Scope-2026-09-07.md — findings, source locations, acceptance criteria, roadmap and references.
- probe_uploaded_snapshot.py — focused, mocked checks against the reviewed source.
- probe-results.json — output recorded during this review.
- manifest.json — reviewed source and document hashes.

## Reproduce the focused probes (macOS or Linux)

Extract your original source archive, then run:

```sh
python3 probe_uploaded_snapshot.py --repo /path/to/gps-time-pi
```

Use Python 3.9 or newer; 3.11+ is recommended for a current test environment.
The probes do not require the Pi, gpsd, chrony, Skyfield, root privileges, or a network.
They mock all exercised receiver/admin paths and use a temporary configuration location.
They never run the installer, reboot the host, restart services, or adjust the clock.

The JSON describes reproduced behavior in the uploaded snapshot. It is not a collection
of passing acceptance tests. After fixes, these outcomes should change and the probes
should be converted into proper regression assertions.
